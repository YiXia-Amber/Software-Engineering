/*
 * COMP201 2019-20
 * Assignment 1
 * Clerk.java *V2*
 * NAME:Yi Xia
 * STUDENT ID:201448617
 * COMPUTER USERNAME:sgyxia7
 */
 
 public class Clerk extends Person{
	private CreditUnion union;
	 
	 public Clerk()
	 {
		 super(); 
	  }
	 
	 public Clerk(CreditUnion theUnion)
	 {
		 super();
		 union = theUnion;
	 }
	 
	 public Clerk(String theName)
	 {
		 super(theName);
	 }
	 
	 public void setUnion(CreditUnion theUnion)
	 {
		 union = theUnion;
	 }
	 
	 
	 public void addAccount(Account theAccount)
	{

		union.accounts.add(theAccount);
		
	}
	
	public void rmAccount(Account theAccount) 
	{       
                try{
                   theAccount.close();
		   union.accounts.remove(theAccount);
	
                }catch(AccountException e){
                   System.out.println(e.getMessage());
                }
        }
	
	public void addCustomer(Customer c)
	{
		union.people.add(c);
		System.out.println("Customer " + c.name + " is registered with the Credit Union");
	}
	
	public void rmCustomer(Customer c)
	{
		union.people.remove(c);
                System.out.print("Customer: "+ c.name + "is removed from the Credit Union");
	}
	 
	 public boolean openSavings(Customer theCustomer, double openAmount)
	 {
		 //Check the Customer is registered with the union
		 if(!(union.people.contains(theCustomer)))
		 {
			 addCustomer(theCustomer);
		 }else{
                         //check the customer has account
                         if(theCustomer.myAccount.getBalance()!=0){
                             System.out.println("Error: Customer already has an account.");
                             return false;
                         }
                 }
		 
			 //Check we are opening the account with a valid amount
			 if(openAmount >=0.0)
			 {
				 try
				 {
					//Create a Saving account for the customer with the openAmount
					Account theAccount = new Savings(openAmount, theCustomer); 
                                        theCustomer.setAccount(theAccount);
					addAccount(theAccount);
					return true;
				 }catch(AccountException e)
				 {
						System.out.println("Account Exception caught whilst opening a savings account");
				 }
				
			 }
		 
		 return false;
	 }
	 
	 public boolean openLoan(Customer theCustomer, double theAmount) 
	 {//TODO: Complete this method - use the Process Loan method to help
		if(!(union.people.contains(theCustomer)))
		{        //check the customer is registered with the union
			 addCustomer(theCustomer);
		}else{
                         if(theCustomer.myAccount.getBalance()!=0){
                             System.out.println("Error: Customer already has an account. ");
                             return false;
                         }
                } 
                if(union.processLoanApplication(this, theAmount)){
                         	try
				 {
					//Create a Saving account for the customer with the openAmount
					Account theAccount = new Loan(theAmount,theCustomer);
					addAccount(theAccount);
                                        theCustomer.setAccount(theAccount);
					return true;
				 }catch(AccountException e)
				 {
					System.out.println("Account Exception caught whilst opening a loan account");
				 }
                }
                System.out.println("failed to open the loan account");
		return false;
	 }
	 
	 public boolean closeAccount()
	 {
		 //use method 'rmAccount' to close account.
		 return true;
	 }
	 
	 public boolean applyInterest()
	{	
                for(int i = 0; i < union.accounts.size();i++){
                   if(union.accounts.elementAt(i) instanceof Loan){
                       double balance = union.accounts.elementAt(i).getBalance();
                       balance = balance*1.0001;      
                       union.accounts.elementAt(i).setBalance(balance);
                   }
                }    
		return true;
	}
}
