
import java.util.logging.Level;
import java.util.logging.Logger;

/*
 * COMP201 Assignment 1
 * Loan.java
 * NAME:Yi Xia
 * STUDENT ID:201448617
 * COMPUTER USERNAME: sgyxia7
 */
 
 public class Loan extends Account{
	 //Default constructor for Loan account - sets initial balance to 0
	public Loan()
	{
		super();
		setBalance(0.0);
	}
	
	public Loan(double amount) throws AccountException
	{
		if(amount > 0.0)
		{
			throw new AccountException("Cannot open a Loan account with positive balance: " + amount);
		}else{
                        setBalance(amount);
                }//TODO: Complete the opening of this Loan account
	}
        
        public Loan(double amount, Customer theCustomer) throws AccountException
	{
		if(amount > 0.0)
		{
			throw new AccountException("Cannot open a Loan account with positive balance: " + amount);
		}else{
                        holder = theCustomer;
		        holder.setAccount(this);
                        setBalance(amount);
                }
	}
	
	public void close() throws AccountException
	{
		if(getBalance() < 0.0)
		{
			throw new AccountException("Cannot close a loan account with negative balance: " + getBalance());
		
                } else
                {    
			System.out.println("Closing the account...");

		}
	}
	
	/**
	 * Makes Payment into the loan account
	 * @return The new balance
	 * @param amount the amount to make payment of
	 */ 
              
       	public double payment(double amount) 
	{
                double check = getBalance() + amount;
                if(check > 0.0)
		{
                   
                     System.out.println("Payment failed: the balance should less than 0.");
             

		}else{
                        setBalance(check);
                }//TODO: Complete this method inline with reqs
		return getBalance();
	}
	
        @Override
	public void withdraw(double amount) throws AccountException
	{
		throw new AccountException("you can't withdraw money from your loan account!");
	}
};
