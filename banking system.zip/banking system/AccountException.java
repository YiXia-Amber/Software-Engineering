/*
* AccountException.java
 * NAME:Yi Xia
 * STUDENT ID:201448617
 * COMPUTER USERNAME:sgyxia7
 * /
 
/** 
* A custom Exception type that is used for signalling an error
* relating to operations upon an account.
* This can be any operation that creates a disallowed state, eg:
* 	- Invalid Opening Balance
* 	- Customer attempting an operation that only a Clerk can do
* 	- Balance on savings account becoming negative
* 
*/
class AccountException extends Exception
{
	AccountException(String s)
	{
		super(s);
	}
}
