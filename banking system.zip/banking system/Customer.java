
/*
 * COMP201 2019-20
 * Assignment 1
 * Customer.java
 * NAME:Yi Xia
 * STUDENT ID:201448617
 * COMPUTER USERNAME:sgyxia7
 */
 
 public class Customer extends Person{
	 public Account myAccount; //The customers account
	 
	 public Customer()
	 {
			super();
	 }
	 
	 public Customer(String theName)
	 {
			super(theName);
	 }
	 
	 public String getName()
	 {
			return name;
	 }
	 
	 public void setName(String newName)
	 {
			name = newName;
	 }
	 
	 public void setAccount(Account theAccount)
	 {
			myAccount = theAccount;
	 }
	 
	 public void makeWithdrawal(double amount) 
	 {
	                try{

                                System.out.println("The balance is "+myAccount.getBalance());
			        myAccount.withdraw(amount);

                        }catch(AccountException e){
                                System.out.println(e.getMessage());
                        }

	 }
	 
	 public double makePayment(double amount)
	 {
			myAccount.payment(amount);
                        System.out.println("The new balance is "+myAccount.getBalance());
			return myAccount.getBalance();
	 }
};
