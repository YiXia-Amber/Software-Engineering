/*
 * COMP201 Assignment 1
 * Person.java
 * NAME:Yi Xia
 * STUDENT ID:201448617
 * COMPUTER USERNAME:sgyxia7
 * 
 */
 
 public class Person{
	 public String name;

     public Person()
     {
         name = new String("UNKNOWN");
     }

     public Person(String theName)
     {
         name = new String(theName);
         System.out.println("A person named " + name + " has been created.");
     }
};
